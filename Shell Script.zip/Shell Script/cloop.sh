#!/usr/bin/env bash

for (( i=0; i<=5; i++ ))
do 
  echo -e "Element is $i" 
done

#<< COM
: "
for (( ; ; ))
do 
  echo -e "INF LOOP"
  sleep 2
done
"
#COM
