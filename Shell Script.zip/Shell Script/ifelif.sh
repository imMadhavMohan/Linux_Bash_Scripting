#!/usr/bin/env bash

read -p "Enter option: " opt

if [[ $opt == start ]]
then 	
   echo -e "starting docker\n"
   systemctl start docker	

elif [[ $opt == stop ]]
then
   echo -e "stopping ocker\n"
   systemctl stop docker

elif [[ $opt == restart ]]
then
   echo -e "restarting docker"
   systemctl restart docker.socket

elif [[ $opt == version ]]
then 
   ver = $(docker -v | cut -d " " -f 3 | tr -d "." )	   	    	
   echo "The ver of docker: $ver\n"	

else 
   echo -e "your option is invalid\n"
   echo -e "valid options are: start stop restart\n"
fi	
