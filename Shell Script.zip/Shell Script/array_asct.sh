#!/usr/bin/env bash

var=$(declare -a)

declare -a arr

read -p "pass elem to arr: " arr

echo -e "${arr[@]}"

arr+=([name]="Docker" [version]="4.4")

echo -e "${arr[*]}"

echo -e "${arr[name]}"
