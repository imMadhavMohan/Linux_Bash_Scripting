#!/usr/bin/env bash

for(( ; ; ))
do
 read -p "num1: " a
 read -p "num2: " b
 read -p "opera: " op

 case $op in
    +)
    awk -v a=$a -v b=$b 'BEGIN {print "sum="a+b}'
    ;;

    -)
    awk -v a=$a -v b=$b 'BEGIN {print "sub="a-b}'
    ;;

    **)
    awk -v a=$a -v b=$b 'BEGIN {print "mul="a*b}'
    ;;

    /)
    awk -v a=$a -v b=$b 'BEGIN {print "div="a/b}'
    ;;

    %)
    awk -v a=$a -v b=$b 'BEGIN {print "mod="a%b}'
    ;;

    *) 
      echo -e "wrong choice"
      ;;
  esac
done

