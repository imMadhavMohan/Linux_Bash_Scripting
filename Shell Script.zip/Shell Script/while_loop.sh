#!/usr/bin/env bash

cnt=1

n=1
while (( $n <= 5 ))
do
   echo "Welcome $n times."
   n=$(( n+1 ))	
done


while [[ $cnt -lt 10 || $cnt -eq 10 ]]
do
  printf "$cnt "
  (( cnt++ ))
done

file="file.txt"

while read each_line
do 
  echo -e "$each_line"
done < $file

cat file.txt | while read line
do 
  echo -e "$line"
done

ls -lrt | while read line
do 
  echo -e "$line"
done



