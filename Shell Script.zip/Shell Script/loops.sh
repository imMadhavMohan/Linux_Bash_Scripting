#!/usr/bin/env bash

var=(1 2 3 4 5)

# 1 way
for each in ${var[@]}
do
  echo -e "Hey ${each}"
done

for each in ${var[@]}
do
  (( res=$each & 1 )) 
  if [[ $res -eq 0 ]]
  then	
     echo -e "$each is even"
  fi
done

# check whether file is executable or not in current dir
#for each in $(ls)
# check whether file is executable or not in custom dir
for each in $(ls $1)
do
  if [[ -x $each  ]]
  then  
     echo -e "$each is executable"
  else 
     echo -e "$each isn't executable"	 
  fi
done


