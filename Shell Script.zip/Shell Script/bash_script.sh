#!/bin/bash

#Author: Madhav Mohan
#Date Modifiy: 31/09/2022
#Current Modify: 31/09/2022
#Description: Task
#Usage: Common task

tar -cvf ./my_backup_"$(date +%d-%m-%Y_%H-%M-%S)".tar *.sh



exit 0

