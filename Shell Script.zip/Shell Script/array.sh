#!/usr/bin/env bash

arr=()

read -p "Give i/p in arr: " -a arr

echo -e "${arr[3]}"  # print at index

echo -e "${arr[@]}"  # print all elements

echo -e "${arr[*]}"  # print all elements

echo -e "${#arr[@]}"  # num of ele

echo -e "${arr[@]:1:5}"  # 1 to 5 

echo -e "${arr[@]:1}"  # 1 to end

echo -e "${!arr[@]}"   # print all indexes

arr+=(8 9 "Hi Maddy")

echo -e "${arr[@]}"  # print all elements

arr1=( [2]="Hi" [5]="Madhav Mohan" )

echo -e "${arr1[@]}" # print all element

