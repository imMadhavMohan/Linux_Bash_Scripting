#!/usr/bin/env bash

cnt=0

for (( ; ; ))
do 
  (( var=$cnt & 1 ))
  (( cnt++ )) # way to do arithmetic operation  
  if [[ cnt -eq 10 ]]
  then
     break
  elif [[ $var -eq 0 ]]
  then
     var=$cnt
     (( var-- ))
     echo -e "the cnt is: ${var}"
  else
     continue
  fi
done

