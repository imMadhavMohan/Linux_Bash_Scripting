#!/bin/bash
s="Madhav Mohan"
echo "welcome $s\n"
<< COM
{
ls
date
pwd
}
COM

touch maddy.txt

user=$(id -u)
[[ $user -eq 0 ]] && echo "Root user" || echo "not a root user\n"

#date && -ls || pwd  # || pwd

if date && ls
then
   echo -e "Hi madhav\n"
else 
   echo -e "Bye madhav\n"		
fi

echo -e "\n\n"
which docker && { echo "docker starts\n" ; echo "docker ver: $(docker -v)\n"; }

#echo -e "prog name: $0\n name is: $1 \n Age is: $2 \n gen is: $3 \n two digit ip: ${10}"
#echo -e "all arg: $@ \n all arg: $* \n num of arg: $# "
