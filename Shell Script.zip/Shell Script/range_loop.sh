#!/usr/bin/env bash

for i in {6..0}
do 
  printf "$i "
done

  echo -e


for i in {6..0..2}
do 
  printf "$i "
done

  echo -e


for i in {0..10}
do 
  printf "$i "
done

for i in {0..10..2}
do 
    printf "$i "
done

    echo -e

for i in {a..j..2}
do 
  printf "$i "
done

  echo -e
 
for i in {j..a..2}
do 
  printf "$i "
done

echo -e
