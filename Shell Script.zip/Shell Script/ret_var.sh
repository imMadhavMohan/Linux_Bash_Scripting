#!/usr/bin/env bash

ret_var(){
  local x=9
  local y=10
  echo -e "local x is: $x" # return to global scope
}

var=$(ret_var)

echo -e "y isn't accessible in global scope: $y"
echo -e "ret val is: $var"

ret_str(){
 local str="Madhav mohan"
 echo -e "In local scope: $str"
}

ret_str

echo -e "In global scope: $str"


