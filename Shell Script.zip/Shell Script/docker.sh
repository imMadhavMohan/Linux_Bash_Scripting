#!/bin/bash
version=$(systemctl status docker | awk '/Active/ {print $7}' | tr -d "[()]")
status=$(systemctl status docker | awk '/Active/ {print $3}' | tr -d "[()]")
echo "The version is:$version"
echo "The status is:$status"

# 1st use
echo -e -n "This first line\t"
echo "The second\t line"

# 2nd \n \b \r \b \t \
echo -e "The 3rd line\nThe fourth line \"maddy\"\v"
echo -e "The 5th line\tThe 6th line"
echo -e "Hi dear \t "madhav" \v bye"

echo -e "ok\bfine"
echo -e "ok\rfine"

echo -e "\033[0;33m Hi dear "madhav" bye\033[0m"
