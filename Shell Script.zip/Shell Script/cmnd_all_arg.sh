#!/usr/bin/env bash

# here we'll see difference bw $@ & $*

# you'll see no diference
for each in $*
do 
  echo -e "$each"
done 

echo -e "\n"

for each in $@
do 
  echo -e "$each" 
done 

# actual diff
for each in "$*" # it'll consider "Hi Hello" as two different arg
do 
  echo -e "$each"
done 

echo -e "\n"

for each in "$@" # it'll consider "Hi Hello" as single arg
do 
  echo -e "$each" 
done 

