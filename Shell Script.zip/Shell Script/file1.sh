#!/usr/bin/env bash

#set -x
#set -e
name="madhav mohan pachori"

echo -e "${name^^}"

name="Madhav Mohan"
nme=${name/Madhav/Mukund}
echo -e "$name" |sed 's/Madhav/Mukund/'
echo -e "$nmes"
echo -e "$nme"

cmd=$(date)
cmnd=$(pwd)

var=$(date)

var1=$var
echo -e "${var1}"

echo -e ${cmnd}
echo -e ${cmd}
echo -e $name
echo -e "${#name}"

fn="Madhav "
ln="Mohan"

echo -e "$fn $ln"
echo -e $fn $ln
echo -e "Hi madhav"

read -p "Enter your name: " name
echo -e "$name"

read -p "enter your age: " 
echo -e "$REPLY"
