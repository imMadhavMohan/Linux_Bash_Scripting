#!/usr/bin/env bash

add_num(){
  x=$1
  y=$2

#  z=$0  has ./param

  echo -e $0
  res=$(( x+y ))
  echo -e "res is: $res"
}

var1=4
var2=6

add_num var1 var2

add_num 12 3
