#!/usr/bin/env bash

read -p "val of a: " a
read -p "val of b: " b

# without bah calc we can do arithematic oper

echo "$a $b" | awk 'a=$1;b=$2;{print "sum="a+b}'

awk -v x=$a -v y=$b 'BEGIN {print "div="x/y;print "mul="x*y}'
