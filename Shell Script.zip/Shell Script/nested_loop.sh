#!/usr/bin/env bash

for ((i=0;i<=2;i++))
do 
  for((j=0;j<=2;j++))
  do 
      echo -n "$i$j "
  done
      echo -e
done
