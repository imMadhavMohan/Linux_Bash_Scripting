#!/bin/bash

#read user input
read -p "Please enter username:" username

#search for username in /etc/passwd file and print details on the screen
cat /etc/passwd | awk -F : "/$username/"' { print $5}'
#printf "%*15c" " "
cat /etc/passwd | awk -v name="$username" ' $0 ~ name {print $0}'
