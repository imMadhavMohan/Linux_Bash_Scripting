#!/usr/bin/env bash

file="file.txt"

while IFS=, read f1 f2 
do 
  [ #id -u -eq 0 ] && echo -e "field-1 $f1 => field-2 $f2"
done > $file


