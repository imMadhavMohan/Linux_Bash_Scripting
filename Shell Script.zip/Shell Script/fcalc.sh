#!/usr/bin/env bash
read -p "input float num1: " a
read -p "input float num1: " b

echo -e "press 1. add ; 2. sub ; 3. mul ; 4. div "
read -p "Opt is: " res

case $res in
     1) 
	sum=$(bc<<<"scale=3; $a+$b")	
	echo -e "sum is: $sum \n" 
	;;
     2)
	sub=$(bc<<<"scale=3; $a-$b")	 	
	echo -e "sub is: $sub\n"
	;;
     3)
	mul=$(bc<<<"scale=3; $a*$b")
	echo -e "mul is: $mul\n"
	;;
     4) 
	div=$(bc<<<"scale=3; $a/$b")
	echo -e "div is: $div\n"
	;;
     *)
	echo -e "wrong choice"
	;;				
esac
