#!/bin/bash
cat << EOF | grep -E "Madhav"
"Hi Madhav Mohan"
"Come Here"
EOF

echo -e "Hi"

cat <<EOF > text.txt
Hi Madhav Mohan
what are you waiting for just 
shake the world
EOF

name="Madhav Mohan"
echo EOF | tr [a-z] [A-Z] <<<$name >> file.txt
echo EOF | tr [a-z] [A-Z] <<<$name

# comment I m

: '
 Hi madhav mohan I
 m comment do you
 know ok wait
'

<< MYCOM
 Hi mukund Im comment
 even of multi line
 you know
MYCOM
