#!/usr/bin/env bash

TO="vocabularyque@gmail.com"
# fro preventive purpose im giving -1 ram limit
limit=-1
free_RAM=$(free -gt | grep -E "Total" | awk '{print $4}')

if [[ $free_RAM -lt $limit ]]
then
  echo -e "Server is running with low RAM Size on $(hostname)\nAvailable RAM is: $free_RAM" | mail -s "Ram alert $(date)" $TO 
fi
