LANGUAGE=en_IN:en
HOME=/root
LOGNAME=root
PATH=/usr/bin:/bin
LANG=en_IN
SHELL=/bin/sh
PWD=/root
