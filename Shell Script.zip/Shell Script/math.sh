#!/usr/bin/env bash
read -p "input num1: " a
read -p "input num2: " b

<<COM
((sum=a+b))
echo -e "sum is: $sum\n floating operation"
COM

read -p "input float num1: " a
read -p "input float num2: " b
fsum=$(bc<<<"scale=2;$a+$b")
echo -e "float sum is: $fsum"

fdiv=$(bc<<<"scale=3;$a/$b")
echo -e "float div is: $fdiv"
