#!/usr/bin/env bash

fuse=$(df -H | grep -Ev "tmpfs|udev" | grep "sda5" | awk '{print $5}' | sed 's/%//')
TO="vocabularyque@gmail.com"
lim=17 # for prevention

if [[ $fuse -gt $lim ]]
then
#in case of error we can also give full path /bin/mail instead of mail
   echo -e "The file system alert on $(hostname) on date $(date) with current usage: $fuse" | mail -s "FILE_SYSTEM_USAGE" $TO <<< "Kindly check your file_sys $(date)"
fi

