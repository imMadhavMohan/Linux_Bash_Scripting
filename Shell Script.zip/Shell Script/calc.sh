#!/usr/bin/env bash
read -p "Input num1: " a
read -p "Input num2: " b

echo -e "press 1 add ; 2 sub ; 3 mul ; 4 div"
read -p "opt choice is: " opt

# for int input only
case $opt in
   1) 
	((sum=$a+$b))
	echo -e "sum is: $sum \n"
	;;
   2) 
	((sub=$a-$b))
	echo -e "sub is: $sub \n"
	;;
   3)
	((mul=$a*$b))
	echo -e "mul is: $mul \n"		 	
	;;
   4) 
	((div=$a/$b))	 	
	echo -e "mul is: $div \n"		 
	;;	
   *)
	echo -e "wrong choice\n"	
	;;
	 
esac
