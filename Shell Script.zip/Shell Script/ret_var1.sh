#!/usr/bin/env bash

ret_var(){
  local x=9
  local y=10
  return $x # return to global scope
}

ret_var
var=$?
echo -e "$var"

ret_str(){
 local str="Madhav mohan"
 echo "Hi $str" # cant use return for string
}

var=$(ret_str)

echo -e "In global scope: $var"
