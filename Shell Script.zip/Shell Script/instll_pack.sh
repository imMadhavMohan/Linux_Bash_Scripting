#!/usr/bin/env bash

sudo apt install apache2 
