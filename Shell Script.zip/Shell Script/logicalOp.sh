#!/usr/bin/env bash
echo -p "Logical or"

read -p "enter your age: " age


#if [[ $age -gt 18 || $age -lt 50 ]]
if [ $age -gt 18 -o $age -lt 50 ]
then
   echo -e "you can avail insurance\n"	
else 
   echo -e "you can't avail insurance\n"		
fi

echo -e "Logical and"

read -p "enter your age: " age
read -p "enter your city: " city

if [[ $city="Agra" -a $age -ge 18 ]]
#if [[ $city="Agra" ]] &&  [[ $age -ge 18 ]]
#if [[ $city=="Agra" &&  $age -gt 18 ]]
#if [ $city=="Agra" -a  $age -ge 18 ]
then
   echo -e "Most welcom\n"
else 
   echo -e "Access restricted\n"	
fi
	

