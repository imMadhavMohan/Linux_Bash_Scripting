#!/usr/bin/bash
#a simple ex
# i'm a comment
echo "This is first scripting file"
exit 0

