#!/usr/bin/env bash

for i in $(seq 0 2 10)
do 
  printf "E-$i "
done

echo -e "seq command\n"

for i in $(seq 10 -2 0)
do 
  printf "E-$i "
done

echo -e "seq command\n"

for i in $(seq 0 10)
do 
  printf "E-$i "
done

echo -e "seq command\n"

for i in $(seq 10 -1 0)
do 
  printf "E-$i "
done


echo -e "seq command\n"
