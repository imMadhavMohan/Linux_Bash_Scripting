#!/usr/bin/env bash

: "
while true
do
 echo -e "Run INF"
done

while :
  echo -e "Run INF"
done
"

while date &> /dev/null # o/p redirect to the null no matter success or error
do
 echo -e "RUN INF"
done
