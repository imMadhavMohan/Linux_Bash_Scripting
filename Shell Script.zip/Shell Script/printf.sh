printf -v var1 "Enter you age "
printf "%s \n" "$var"
#!/usr/bin/env bash
: '
printf "enter your Fname:\n"
read fname

printf "enter surname:\n"
read lname

printf "Welcome: %s %s\n" "$fname $lname"
'

var="hello"
printf "|%10s|\n" "$var 5fname"

var=58.973456
printf "%.3f\n" "$var"

printf "%12.3f\n" "$var"

printf "%-12.3f\n" "$var"

printf "%012.3f\n" "$var"

printf "%12.3f\n" "$var"

var="Maddy Mohan"
printf -v var 'Welcome'
printf '%s\n' "$var"

# current date
var=123456789
printf "%'d\n" "$var"

printf 'Today is %(%F)T\n' -1 # -1 indicates the current date 
